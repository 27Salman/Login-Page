import express from 'express';
import session from 'express-session';
import nocache from 'nocache';

const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');

app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use(nocache());
app.use(
  session({
    secret: 'EbiDev',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 5 * 60000 },
  })
);

// user details
const users = [
  { email: 'salmanas@gmail.com', password: 'salman1234' },
  { email: 'safwanas@gmail.com', password: 'safwan1234' },
];   
app.get('/', (req, res) => {
  if (req.session.user) {
    res.redirect('/home'); 
  } else {
    res.render('index', { error: false });
  }
});

app.post('/login', (req, res) => {
  const { email, password } = req.body;
  const user = users.find(el => el.email === email);
  if (user && user.password === password) {
    const userName = user.email.split('@')[0];
    req.session.user = userName;
    res.redirect('/home');
  } else {
    res.render('index', { error: true });
  }
});

app.get('/home', (req, res) => {
  if (req.session.user) {
    const userName = req.session.user;
    res.render('home', { user: userName });
  } else {
    res.redirect('/');
  }
});

app.post('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.log('Failed to logout', err);
      res.status(500);
      res.send('an error occur');
    } else {
      res.redirect('/');
    }
  });
});
app.get('*', (req, res) => {
  res.status(404);
  res.send('OOps that page not found');
});

app.listen(PORT, () => {
  console.log(`Server is running on the ${PORT}`);
});
